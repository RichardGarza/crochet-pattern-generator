# CODING AGENTS: READ THIS FIRST

This is a handoff bundle from Claude Design. The design files are in `project/`; the conversation is in `chats/`.
