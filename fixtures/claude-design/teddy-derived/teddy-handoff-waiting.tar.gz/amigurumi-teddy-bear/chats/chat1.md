## User

Model a 3D object: an amigurumi teddy bear.

## Claude

Before I start: should the bear sit or stand?
